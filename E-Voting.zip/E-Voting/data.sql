create database evote;
use evote;

create table admin(id varchar(10), password varchar(10));
insert into admin values('admin','abc');

create table candidates (
name varchar(10),
const varchar(10),
vote int
);
insert into candidates values('Mohan', 'Delhi',5);
insert into candidates values('Sohan', 'Delhi',2);
insert into candidates values('Rohan', 'Delhi',0);
insert into candidates values('Ramesh', 'Ghaziabad',7);
insert into candidates values('Suresh', 'Ghaziabad',2);
insert into candidates values('Mukesh', 'Ghaziabad',5);
insert into candidates values('Ram', 'Noida',3);
insert into candidates values('Shyam', 'Noida',7);
insert into candidates values('Ghanshyam', 'Noida',9);


create table voter (
name varchar(10),
fname varchar(10),
dob varchar(10), 
gender varchar(10),
password varchar(10),
epic int,
consti varchar(10),
address varchar(10),
district varchar(10),
state varchar(10),
pin int
);
insert into voter values('Mohit', 'Modak', '07/05/1990', 'm', 'mohit1990', '123', 'Delhi', 'Model Town', 'Delhi', 'Delhi', '201992');
insert into voter values('Rohit', 'Raunak', '16/08/1980', 'm', 'rohit1980', '456', 'Ghaziabad', 'Nand Gram', 'Ghaziabad', 'UP', '201008');
